function T = trans_hom(R, t)
    T = [R, t; 0,0,0,1];
end