% =========================================================================
% MT3005 - LABORATORIO 3: �ngulos de Euler y transformaciones elementales
% -------------------------------------------------------------------------
% Ver las instrucciones en la gu�a adjunta
% =========================================================================
%% Inciso 2.
% Sub-inciso (a)
phi1 = 0; 
theta1 = 0;
psi1 = 0;
AT_D = 0;

% Sub-inciso (b)
phi2 = 0;
theta2 = 0;
psi2 = 0;
CT_D = 0;

% Sub-inciso (c)
phi3 = 0;
theta3 = 0;
psi3 = 0;
AT_C = 0;

% Sub-inciso (d)
AT_B = 0;

% Sub-inciso (e)
% Mostrar figura marcos de referencia

%% Inciso 3. 
% Sub-inciso (a)
AT_Da = 0; 

% Sub-inciso (b)
AT_Db = 0;

% Sub-inciso (c)
AT_Dc = 0;

% Sub-inciso (d)
AT_Dd = 0;

% Sub-inciso (e)
AT_De = 0;